# Desafio 08 – Tool Router com Sandbox Tools e Production Tools

## Visão Geral

Após a criação do Workspace Seguro e da introdução ao Sandbox Runner, o próximo passo é controlar como as ferramentas são disponibilizadas para os agentes.

Neste módulo construiremos o Tool Router, componente responsável por decidir quais ferramentas podem ser utilizadas em cada ambiente.

---

# Objetivos

- Implementar roteamento de ferramentas.
- Separar Sandbox Tools de Production Tools.
- Aplicar políticas de segurança.
- Preparar a arquitetura para LangChain Tools.
- Preparar integração futura com LangGraph.

---

# Problema Arquitetural

Sem um roteador de ferramentas, qualquer agente pode acessar qualquer recurso.

Isso cria riscos:

- Exclusão indevida de dados.
- Chamadas reais durante testes.
- Custos desnecessários.
- Baixa auditabilidade.

---

# Arquitetura

```text
Agent
  |
  v
Tool Router
  |
  +-- Sandbox Tools
  |
  +-- Production Tools
```

---

# Estrutura de Diretórios

```text
tools/
├── sandbox_tools/
├── production_tools/
├── registry/
└── router/
```

---

# Catálogo de Ferramentas

Cada ferramenta deverá possuir metadados:

```yaml
name: read_logs
category: file
mode:
  - sandbox
  - production
```

---

# Fluxo de Decisão

```mermaid
flowchart TD
A[Agent Request] --> B{Environment}
B -->|Sandbox| C[Sandbox Tool]
B -->|Production| D[Production Tool]
```

---

# Exercício 1

Criar registro central de ferramentas.

# Exercício 2

Implementar validação de ambiente.

# Exercício 3

Criar duas versões da mesma ferramenta:

- Fake Create Ticket
- Real Create Ticket

---

# Observabilidade

Registrar:

- Ferramenta solicitada
- Ferramenta executada
- Ambiente
- Tempo de execução

---

# Critérios de Aprovação

- Tool Router funcional.
- Ferramentas segregadas por ambiente.
- Logs gerados.
- Testes executados.

---

# Armadilhas Comuns

- Executar ferramenta de produção em sandbox.
- Não validar modo de execução.
- Acoplamento entre Agent e Tools.

---

# Perguntas de Revisão

1. O que é Tool Router?
2. Qual a diferença entre Sandbox Tool e Production Tool?
3. Por que registrar o ambiente?
4. Como esse componente reduz riscos?

---

# Relação com a Arquitetura Final

Este módulo prepara a base para:

- Desafio 10 – LLM Factory
- Desafio 12 – Sandbox Runner Completo
- Desafio 14 – Replay Engine
- Desafio 17 – Homologação

---

# Próximo Módulo

Desafio 09 – Memória Vetorial para Sandbox e Produção.
